<?php

if (!defined('INDEX')) die("");
?>

<h2 class="judul">Informasi</h2>
<p>User yang dapat menggunakan layanan ini adalah Mahasiswa, Dosen dan Staf kampus </p>