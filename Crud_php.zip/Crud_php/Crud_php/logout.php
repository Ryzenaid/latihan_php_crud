<?php

session_start();
session_destroy();
?>

<p>Logout Berhasil, silahkan <a href="login.php">Login</a> kembali</p>